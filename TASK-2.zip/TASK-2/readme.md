Markdown

# 🛒 AI-Powered Personal Shopper

An intelligent product discovery tool that uses **Semantic Search** and **Local Embeddings** to rank shopping results based on intent rather than just keywords.

!

## 🌟 Features
- **Semantic Ranking:** Uses LM Studio embeddings to calculate cosine similarity between your request and product descriptions.
- **Real-time Search:** Fetches live data from Google Shopping via SerpAPI.
- **Interactive UI:** Impressive product card layout with hover effects and responsive grids.
- **Comparison Engine:** Side-by-side comparison tray in the sidebar to track top picks.
- **Visual Analytics:** Simulated price history and sentiment analysis for smarter decision-making.

---

## 🛠️ Tech Stack
- **Frontend:** [Streamlit](https://streamlit.io/)
- **Embeddings:** [LM Studio](https://lmstudio.ai/) (Local Inference)
- **Search API:** [SerpAPI](https://serpapi.com/) (Google Shopping Engine)
- **Math:** NumPy (Cosine Similarity)

---

## 🚀 Setup Instructions

### 1. Prerequisites
* **Python 3.8+**
* **LM Studio:** Download and run LM Studio. Load an embedding model (e.g., `text-embedding-all-minilm-l6-v2`) and start the Local Server on port `1234`.
* **SerpAPI Key:** Get a free API key from [SerpAPI](https://serpapi.com/).

### 2. Installation
Clone this repository or download the source code:

```bash
# Install dependencies
pip install -r requirements.txt
3. Configuration
Open app.py and update the following variables:

Python

LMSTUDIO_EMBEDDING_URL = "http://localhost:1234/v1/embeddings"
SERPAPI_KEY = "YOUR_ACTUAL_SERPAPI_KEY"
4. Running the App
Bash

python -m streamlit run app.py
🧠 How it Works: Cosine Similarity
Unlike standard search which looks for exact words, this app converts your query and the product details into mathematical vectors. It then calculates the angle between these vectors:

Score 1.0: Perfect semantic match.

Score 0.0: No relation.

📂 Project Structure
Plaintext

├── app.py              # Main Streamlit application
├── requirements.txt    # Python dependencies
└── README.md           # Project documentation